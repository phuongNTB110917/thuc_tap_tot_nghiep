package com.example.webbookstore.model;

public enum AuthProvide {
    local,
    facebook,
    google,
}
