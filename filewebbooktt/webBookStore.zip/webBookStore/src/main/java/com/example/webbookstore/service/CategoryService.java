package com.example.webbookstore.service;

import com.example.webbookstore.model.Category;

import java.util.List;

public interface CategoryService {
    List<Category> findAll();
}
