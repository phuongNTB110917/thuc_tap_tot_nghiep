package com.example.webbookstore.model;


public enum GenderType {
    male,
    female,
    other
}