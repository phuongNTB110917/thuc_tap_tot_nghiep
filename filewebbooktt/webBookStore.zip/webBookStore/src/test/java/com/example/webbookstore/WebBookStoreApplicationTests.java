package com.example.webbookstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebBookStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
